import Navigation from "@/components/navigation";
import Hero from "@/components/hero";
import Experience from "@/components/experience";
import Skills from "@/components/skills";
import Education from "@/components/education";
import Contact from "@/components/contact";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useState } from "react";

export default function Portfolio() {
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownloadCV = async () => {
    setIsDownloading(true);
    try {
      const response = await fetch("/api/download-cv");
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "Sahil_Garg_CV.pdf";
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } else {
        console.error("Failed to download CV");
      }
    } catch (error) {
      console.error("Error downloading CV:", error);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      <Navigation />
      <Hero onDownloadCV={handleDownloadCV} isDownloading={isDownloading} />
      {/* Key Achievements Banner */}
      <section className="py-16 bg-gradient-to-r from-slate-50 to-blue-50 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold gradient-text mb-4">Key Achievements</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Delivering measurable impact across organizations through strategic HR leadership</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center group">
              <div className="relative">
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center hover-lift shadow-lg">
                  <span className="text-3xl font-bold text-white">10+</span>
                </div>
                <div className="absolute -inset-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity blur-lg"></div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-1">Years Experience</h3>
              <p className="text-sm text-gray-600">HR Leadership</p>
            </div>
            
            <div className="text-center group">
              <div className="relative">
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center hover-lift shadow-lg">
                  <span className="text-3xl font-bold text-white">20%</span>
                </div>
                <div className="absolute -inset-2 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity blur-lg"></div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-1">Retention Improvement</h3>
              <p className="text-sm text-gray-600">Employee Engagement</p>
            </div>
            
            <div className="text-center group">
              <div className="relative">
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center hover-lift shadow-lg">
                  <span className="text-2xl font-bold text-white">1400+</span>
                </div>
                <div className="absolute -inset-2 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity blur-lg"></div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-1">Employees Managed</h3>
              <p className="text-sm text-gray-600">Team Leadership</p>
            </div>
            
            <div className="text-center group">
              <div className="relative">
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center hover-lift shadow-lg">
                  <span className="text-3xl font-bold text-white">60%</span>
                </div>
                <div className="absolute -inset-2 bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity blur-lg"></div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-1">Offer Acceptance</h3>
              <p className="text-sm text-gray-600">Recruitment Success</p>
            </div>
          </div>
        </div>
      </section>

      <Experience />
      <Skills />
      <Education />
      <Contact onDownloadCV={handleDownloadCV} isDownloading={isDownloading} />
      
      {/* Footer */}
      <footer className="bg-gray-900 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-400">&copy; 2024 Sahil Garg. All rights reserved.</p>
            <p className="text-gray-500 mt-2">Senior HR Professional | Driving organizational excellence through strategic HR initiatives</p>
          </div>
        </div>
      </footer>

      {/* Floating Download Button */}
      <div className="fixed bottom-8 right-8 z-50">
        <Button
          onClick={handleDownloadCV}
          disabled={isDownloading}
          className="w-16 h-16 gradient-bg rounded-full shadow-2xl hover:shadow-3xl hover-lift pulse-ring border-0"
          title="Download CV"
        >
          <Download className="w-8 h-8 text-white" />
        </Button>
      </div>
    </div>
  );
}
