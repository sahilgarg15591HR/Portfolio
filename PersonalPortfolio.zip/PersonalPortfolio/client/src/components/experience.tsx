import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle } from "lucide-react";

export default function Experience() {
  const experiences = [
    {
      title: "Senior Manager – Human Resources",
      company: "Cashfree Payments India Private Ltd",
      location: "Bangalore, India",
      period: "June 2022 – Present",
      current: true,
      description: "Leading HRBP & TA function for Engineering (Tech), Product, Design & Data Analytics teams. Previously led HRBP for all Business & Corporate functions.",
      achievements: [
        "Reduced employee cost by 10%, improved retention by 20%, boosted engagement by 10bps",
        "Built dashboards to track metrics and deliver insights to senior leadership",
        "Implemented Competency and OKR-based Performance Review system"
      ]
    },
    {
      title: "HR Head",
      company: "SenseHawk India Private Ltd",
      location: "Abu Dhabi, UAE",
      period: "Aug 2021 – May 2022",
      current: false,
      description: "Led HR for a Series A-funded multinational solar-tech startup.",
      achievements: [
        "Established UAE office with seamless relocation for 30+ employees, 100% retention",
        "Designed and implemented all HR frameworks from scratch"
      ]
    },
    {
      title: "People Partner – Product, Technology & Supply Chain",
      company: "BYJU'S (Think & Learn Private Ltd)",
      location: "Bangalore, India",
      period: "Nov 2019 – Aug 2021",
      current: false,
      description: "Led HRBP for 1400+ employees across Tech, Product, Game Studio, and Post-Sales teams.",
      achievements: [
        "Scaled post-sales operations team to 2x through streamlined hiring processes",
        "Achieved 60% increase in offer acceptance rate through compensation benchmarking"
      ]
    },
    {
      title: "HR Business Partner – Group Manufacturing",
      company: "Reliance Industries Limited",
      location: "Mumbai, India",
      period: "June 2017 – Nov 2019",
      current: false,
      description: "HRBP for 500+ employees across corporate functions, supporting 20,000+ manufacturing employees.",
      achievements: [
        "Developed in-house hiring platform, reducing recruitment TATs by 50%",
        "Focused on talent initiatives including workforce planning and succession planning"
      ]
    }
  ];

  return (
    <section id="experience" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 to-purple-50/30"></div>
      <div className="absolute top-1/3 left-0 w-96 h-96 bg-gradient-to-r from-blue-200/20 to-purple-200/20 rounded-full blur-3xl transform -translate-x-1/2"></div>
      <div className="absolute bottom-1/3 right-0 w-96 h-96 bg-gradient-to-r from-purple-200/20 to-pink-200/20 rounded-full blur-3xl transform translate-x-1/2"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-4xl font-bold gradient-text sm:text-5xl mb-6">Professional Experience</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">A decade of progressive growth in Human Resources leadership across innovative companies</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {experiences.map((exp, index) => (
            <Card key={index} className="group hover-lift bg-white/90 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-500 border-0 overflow-hidden h-fit">
              <CardContent className="p-6 relative">
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-purple-100/50 to-blue-100/50 rounded-full transform translate-x-8 -translate-y-8"></div>
                
                <div className="relative z-10">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 group-hover:text-purple-700 transition-colors mb-2 line-clamp-2">
                        {exp.title}
                      </h3>
                      <p className="text-lg font-semibold gradient-text mb-1">{exp.company}</p>
                      <div className="flex items-center justify-between mb-3">
                        <p className="text-sm text-gray-500 flex items-center">
                          <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                          {exp.location}
                        </p>
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                          {exp.period}
                        </span>
                      </div>
                    </div>
                    {exp.current && (
                      <Badge className="bg-gradient-to-r from-green-400 to-emerald-500 text-white hover:from-green-500 hover:to-emerald-600 border-0 shadow-lg ml-2 shrink-0">
                        Current
                      </Badge>
                    )}
                  </div>
                  
                  <p className="text-gray-700 mb-4 leading-relaxed text-sm">{exp.description}</p>
                  
                  <div className="space-y-2">
                    {exp.achievements.map((achievement, achIndex) => (
                      <div key={achIndex} className="flex items-start group/item">
                        <div className="w-4 h-4 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mt-0.5 mr-2 flex-shrink-0 group-hover/item:scale-110 transition-transform">
                          <CheckCircle className="w-2 h-2 text-white" />
                        </div>
                        <p className="text-xs text-gray-600 leading-relaxed group-hover/item:text-gray-800 transition-colors">
                          {achievement}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
