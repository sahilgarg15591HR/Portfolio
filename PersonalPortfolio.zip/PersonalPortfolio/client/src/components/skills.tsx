import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Briefcase, DollarSign, BarChart3, Shield, Zap } from "lucide-react";

export default function Skills() {
  const skillCategories = [
    {
      title: "HR Business Partnership",
      description: "HR Strategy, AOP, Budgeting, Talent Management, Workforce Planning, Organizational Development",
      icon: Users,
      color: "from-blue-50 to-blue-100",
      iconBg: "bg-primary",
      tags: ["HRBP", "Strategy", "Planning"]
    },
    {
      title: "Talent Acquisition",
      description: "Leadership Hiring, Hiring Efficiency, Onboarding, Offer Management",
      icon: Briefcase,
      color: "from-green-50 to-green-100",
      iconBg: "bg-green-600",
      tags: ["Recruitment", "Leadership", "Onboarding"]
    },
    {
      title: "Total Rewards",
      description: "Compensation, Benefits, Compensation Benchmarking, Pay-bands",
      icon: DollarSign,
      color: "from-purple-50 to-purple-100",
      iconBg: "bg-purple-600",
      tags: ["Compensation", "Benefits", "ESOP"]
    },
    {
      title: "Performance Management",
      description: "OKRs, Competency Frameworks, Appraisal Process",
      icon: BarChart3,
      color: "from-orange-50 to-orange-100",
      iconBg: "bg-orange-600",
      tags: ["OKRs", "Appraisal", "Reviews"]
    },
    {
      title: "HR Analytics & Compliance",
      description: "HR Analytics & Dashboards, Compliance, Labor Laws, Investigations",
      icon: Shield,
      color: "from-teal-50 to-teal-100",
      iconBg: "bg-teal-600",
      tags: ["Analytics", "Compliance", "Legal"]
    },
    {
      title: "Industry Expertise",
      description: "Fintech, Manufacturing, Education, Technology, Construction",
      icon: Zap,
      color: "from-indigo-50 to-indigo-100",
      iconBg: "bg-indigo-600",
      tags: ["Fintech", "Tech", "EdTech"]
    }
  ];

  return (
    <section id="skills" className="py-24 bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="absolute top-1/4 left-10 w-64 h-64 bg-purple-300/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 right-10 w-80 h-80 bg-blue-300/20 rounded-full blur-3xl"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-4xl font-bold gradient-text sm:text-5xl mb-6">Core Competencies</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">Specialized expertise across the HR spectrum with proven impact across diverse industries</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((skill, index) => (
            <Card key={index} className="group hover-lift bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-500 overflow-hidden">
              <CardContent className="p-8 relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-transparent to-purple-100/50 rounded-full transform translate-x-16 -translate-y-16"></div>
                
                <div className="relative z-10">
                  <div className={`w-16 h-16 ${skill.iconBg} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <skill.icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-purple-700 transition-colors">
                    {skill.title}
                  </h3>
                  
                  <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                    {skill.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2">
                    {skill.tags.map((tag, tagIndex) => (
                      <Badge 
                        key={tagIndex} 
                        className="text-xs bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700 hover:from-purple-200 hover:to-blue-200 transition-colors border-0"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <div className="inline-flex items-center justify-center space-x-2 px-6 py-3 bg-white/60 backdrop-blur-sm rounded-full shadow-lg">
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-gray-700">Expertise across Fintech • EdTech • Manufacturing • Technology</span>
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
          </div>
        </div>
      </div>
    </section>
  );
}
