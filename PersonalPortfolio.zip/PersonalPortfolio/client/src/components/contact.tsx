import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Phone, Mail, MapPin, Download } from "lucide-react";
import { SiLinkedin } from "react-icons/si";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ContactProps {
  onDownloadCV: () => void;
  isDownloading: boolean;
}

export default function Contact({ onDownloadCV, isDownloading }: ContactProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: ""
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const contactMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/contacts", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "Thank you for reaching out. I'll get back to you soon.",
      });
      setFormData({ name: "", email: "", phone: "", message: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to send message",
        description: "Please try again or contact me directly via email or phone.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Please fill in all required fields",
        description: "Name, email, and message are required.",
        variant: "destructive",
      });
      return;
    }
    contactMutation.mutate(formData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <section id="contact" className="py-24 gradient-bg relative overflow-hidden">
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="absolute top-10 left-10 w-80 h-80 bg-white/10 rounded-full blur-3xl floating-animation"></div>
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-white/5 rounded-full blur-3xl floating-animation" style={{ animationDelay: '-2s' }}></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-4xl font-bold text-white sm:text-5xl mb-6">Let's Connect</h2>
          <p className="text-xl text-white/90 max-w-3xl mx-auto leading-relaxed">Ready to discuss how I can contribute to your organization's success and drive strategic HR initiatives</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12">
              <div className="text-center group">
                <div className="inline-flex items-center justify-center w-20 h-20 glass-effect rounded-2xl mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                  <Phone className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Phone</h3>
                <p className="text-white/80 text-lg">+91 9082963839</p>
                <p className="text-white/60 text-sm mt-1">Available for calls</p>
              </div>

              <div className="text-center group">
                <div className="inline-flex items-center justify-center w-20 h-20 glass-effect rounded-2xl mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                  <Mail className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Email</h3>
                <p className="text-white/80 text-lg">sahilgarg15591@gmail.com</p>
                <p className="text-white/60 text-sm mt-1">Professional inquiries</p>
              </div>

              <div className="text-center group">
                <div className="inline-flex items-center justify-center w-20 h-20 glass-effect rounded-2xl mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                  <MapPin className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Location</h3>
                <p className="text-white/80 text-lg">Bangalore, India</p>
                <p className="text-white/60 text-sm mt-1">Open to relocation</p>
              </div>

              <div className="text-center group">
                <div className="inline-flex items-center justify-center w-20 h-20 glass-effect rounded-2xl mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                  <SiLinkedin className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">LinkedIn</h3>
                <p className="text-white/80 text-lg">Connect with me</p>
                <p className="text-white/60 text-sm mt-1">Professional network</p>
              </div>
            </div>

            <div className="text-center">
              <Button
                onClick={onDownloadCV}
                disabled={isDownloading}
                size="lg"
                className="inline-flex items-center px-10 py-4 text-lg font-semibold bg-white text-purple-700 hover:bg-white/90 hover-lift pulse-ring shadow-2xl"
              >
                <Download className="w-6 h-6 mr-3" />
                {isDownloading ? "Downloading..." : "Download Complete CV"}
              </Button>
            </div>
          </div>

          {/* Contact Form */}
          <Card className="bg-white/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Send a Message</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Your full name"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="your.email@example.com"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="Your phone number"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="message">Message *</Label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Tell me about your requirements or questions..."
                    rows={4}
                    required
                  />
                </div>
                
                <Button
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="w-full"
                >
                  {contactMutation.isPending ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
