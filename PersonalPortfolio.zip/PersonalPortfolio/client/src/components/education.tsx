import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, Award } from "lucide-react";

export default function Education() {
  const education = [
    {
      degree: "MBA, Human Resources Management",
      institution: "XLRI Jamshedpur",
      period: "2015 - 2017",
      description: "Specialized in Human Resources Management from one of India's premier management institutes, known for excellence in HR education.",
      icon: GraduationCap,
      primary: true
    },
    {
      degree: "B.Tech, Civil Engineering",
      institution: "ITM, Gurgaon (MDU)",
      period: "2009 - 2013",
      description: "Bachelor's degree in Civil Engineering, providing strong analytical and problem-solving foundation that complements HR expertise.",
      icon: Award,
      primary: false
    }
  ];

  return (
    <section id="education" className="py-24 bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 relative overflow-hidden">
      <div className="absolute top-1/4 right-10 w-80 h-80 bg-gradient-to-r from-purple-200/30 to-blue-200/30 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 left-10 w-64 h-64 bg-gradient-to-r from-blue-200/30 to-indigo-200/30 rounded-full blur-3xl"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-4xl font-bold gradient-text sm:text-5xl mb-6">Education</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">Academic foundation and professional development that shaped strategic thinking</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-5xl mx-auto">
          {education.map((edu, index) => (
            <Card key={index} className="group hover-lift bg-white/90 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-500 border-0 overflow-hidden">
              <CardContent className="p-10 relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-purple-100/50 to-blue-100/50 rounded-full transform translate-x-16 -translate-y-16"></div>
                
                <div className="relative z-10">
                  <div className="flex items-start space-x-6">
                    <div className="flex-shrink-0">
                      <div className={`w-20 h-20 ${edu.primary ? 'bg-gradient-to-br from-purple-500 to-blue-500' : 'bg-gradient-to-br from-blue-500 to-indigo-500'} rounded-2xl flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform duration-300`}>
                        <edu.icon className="w-10 h-10 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-gray-900 group-hover:text-purple-700 transition-colors mb-2">
                        {edu.degree}
                      </h3>
                      <p className={`text-lg font-semibold mb-2 ${edu.primary ? 'gradient-text' : 'text-blue-600'}`}>
                        {edu.institution}
                      </p>
                      <div className="mb-4">
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800">
                          {edu.period}
                        </span>
                      </div>
                      <p className="text-gray-600 leading-relaxed">{edu.description}</p>
                      
                      {edu.primary && (
                        <div className="mt-4">
                          <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700">
                            Premier Management Institute
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
