import { Button } from "@/components/ui/button";
import { Download, Mail } from "lucide-react";

interface HeroProps {
  onDownloadCV: () => void;
  isDownloading: boolean;
}

export default function Hero({ onDownloadCV, isDownloading }: HeroProps) {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      const offsetTop = element.getBoundingClientRect().top + window.pageYOffset - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="about" className="relative pt-20 pb-12 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 gradient-bg">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute top-10 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl floating-animation"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-white/5 rounded-full blur-3xl floating-animation" style={{ animationDelay: '-3s' }}></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="items-center">
          <div>
            <div className="mb-8">
              <div className="mb-6">
                <h1 className="text-4xl font-bold text-white sm:text-5xl lg:text-6xl leading-tight">
                  Sahil Garg
                </h1>
                <div className="h-1 w-24 bg-white/80 mt-4"></div>
              </div>
              <p className="text-xl text-white/90 font-medium mb-2">
                Senior HR Professional
              </p>
              <p className="text-lg text-white/80 mb-6">
                XLRI Alumni • 10+ Years Experience
              </p>
              <p className="text-base text-white/90 max-w-2xl leading-relaxed">
                Driving organizational excellence through strategic HR initiatives across 
                <span className="font-semibold text-white"> Fintech, Technology, and Manufacturing</span> sectors. 
                Specialized in talent management, performance optimization, and building high-impact HR frameworks.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={onDownloadCV}
                disabled={isDownloading}
                size="lg"
                className="inline-flex items-center px-6 py-3 text-base font-semibold bg-white text-purple-700 hover:bg-white/90 hover-lift pulse-ring shadow-2xl"
              >
                <Download className="w-5 h-5 mr-2" />
                {isDownloading ? "Downloading..." : "Download CV"}
              </Button>
              <Button 
                variant="outline"
                size="lg"
                onClick={scrollToContact}
                className="inline-flex items-center px-6 py-3 text-base font-semibold border-2 border-white text-white bg-white/10 backdrop-blur-sm hover:bg-white hover:text-purple-700 transition-all duration-300 hover-lift"
              >
                <Mail className="w-5 h-5 mr-2" />
                Get in Touch
              </Button>
            </div>
          </div>
          
          
        </div>
      </div>
    </section>
  );
}
