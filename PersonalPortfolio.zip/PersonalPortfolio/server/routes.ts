import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";
import { z } from "zod";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contacts", async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(validatedData);
      res.json({ success: true, contact });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          error: "Invalid form data", 
          details: error.errors 
        });
      }
      res.status(500).json({ 
        success: false, 
        error: "Failed to submit contact form" 
      });
    }
  });

  // Get all contacts (for admin purposes)
  app.get("/api/contacts", async (req, res) => {
    try {
      const contacts = await storage.getAllContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch contacts" 
      });
    }
  });

  // CV download endpoint
  app.get("/api/download-cv", async (req, res) => {
    try {
      const cvPath = path.join(process.cwd(), "attached_assets", "Sahil Garg XLRI HR_1750593146741.pdf");
      
      if (fs.existsSync(cvPath)) {
        res.download(cvPath, "Sahil_Garg_CV.pdf", (err) => {
          if (err) {
            console.error("Download error:", err);
            res.status(500).json({ error: "Failed to download CV" });
          }
        });
      } else {
        res.status(404).json({ error: "CV file not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to process CV download" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
